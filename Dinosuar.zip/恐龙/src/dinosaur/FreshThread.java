package dinosaur;

import java.awt.Container;

import javax.swing.JOptionPane;

public class FreshThread extends Thread{
	GamePanel gp;
	
	public FreshThread(GamePanel gp) {
		this.gp = gp;
	}
	
	public void run() {
		while(!gp.isFinish()) {
			gp.repaint();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		JOptionPane.showMessageDialog(gp, "         G A M E  O V E R    ");     //跳出弹窗表示结束游戏！
//		
//		Container container = gp.getParent();       //会有空指针异常问题！
//		while (!(container instanceof GameFrame)) {
//			container = container.getParent();
//		}
//		
//		GameFrame gameFrame = (GameFrame)container;
//		gameFrame.restart();
	}

	

}
