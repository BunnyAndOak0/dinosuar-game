package dinosaur;

import java.io.File;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

/**
 * 音乐播放线程
 * @author CSDN上借来的 直接用即可
 *
 */
public class Music extends Thread {
	private String wjm;//

	public Music(String ypwj) {
		wjm = ypwj;
	}

	public void run() {

		File wjl = new File(wjm);// 文件流

		AudioInputStream ypsrl = null;// 音频输入流
		try {
			ypsrl = AudioSystem.getAudioInputStream(wjl);// 把音频文件输入进来
		} catch (Exception e) {

		}

		AudioFormat format = ypsrl.getFormat();// 音频格式处理
		SourceDataLine aqsj = null;
		DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);

		try {
			aqsj = (SourceDataLine) AudioSystem.getLine(info);// 安全性包装
			aqsj.open(format);
		} catch (Exception e) {
		}
		aqsj.start();

		int zjtj = 0;
		byte[] hczj = new byte[1024];// 缓冲字节
		try {
			while (zjtj != -1) {
				zjtj = ypsrl.read(hczj, 0, hczj.length);
				if (zjtj >= 0)
					aqsj.write(hczj, 0, zjtj);
			}
		} catch (Exception e) {

		} finally {
			aqsj.drain();// 将残留部分处理干净
			aqsj.close();
		}
	}

}