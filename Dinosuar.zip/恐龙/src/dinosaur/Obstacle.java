package dinosaur;

import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class Obstacle {
	int count = 5;
	int count2;
	int o_x;
	int o_y;
	int speed = 30;
	int height;
	int weight;
	
	public int getHeight() {
		return height;
	}
	
	public int getWeight() {
		return weight;
	}

	Image image;
	
	public int getO_x() {
		return o_x;
	}
	public void setO_x(int o_x) {
		this.o_x = o_x;
	}
	public int getO_y() {
		return o_y;
	}
	public void setO_y(int o_y) {
		this.o_y = o_y;
	}
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
	
	public Obstacle(int o_x, int o_y) {
		super();
		this.o_x = o_x;
		this.o_y = o_y;
	}
	
	int i = (int)(Math.random() * 4) + 1;
	
	//随机画障碍物
	public void draw() throws IOException {
		BufferedImage image1 = ImageIO.read(new File("image/cactus01.png"));
		BufferedImage image2 = ImageIO.read(new File("image/cactus02.png"));
		BufferedImage image3 = ImageIO.read(new File("image/cactus03.png"));
		
		//随机产生数字
		switch (i) {
		case 1:
			image = image1;
			this.weight = image1.getWidth();
			this.height = image1.getHeight();
			break;
		case 2:
			image = image2;
			this.weight = image2.getWidth();
			this.height = image2.getHeight();
			break;
		case 3:
			image = image3;
			this.weight = image3.getWidth();
			this.height = image3.getHeight();
			break;
		case 4:
			birdPictrue();
			this.weight = 38;
			this.height = 23;
			break;
		}
	}
	
	public void birdPictrue() {
		if (count >= 1) {
			setImage(Toolkit.getDefaultToolkit().getImage("image/bird1.png"));
			count--;
			if (count == 1) {
				count2 = 1;
			}
		}else {
			setImage(Toolkit.getDefaultToolkit().getImage("image/bird2.png"));
			count2++;  //1
			if (count2 == 5) {
				count = 5;
			}
		}
	}
	
	public void moveObstacles() throws IOException {
		setO_x(this.o_x - speed);
	}
	
	//返回一个矩形
	public Rectangle getRec() {
		return new Rectangle(o_x, o_y, getWeight(), getHeight());
		
	}
	
//	public Rectangle getNextRec() {
//		return new Rectangle(o_x - speed, o_y, getWeight(), getHeight());
//	}     //好像不需要这个诶

	//检测是否碰撞
	public boolean is_Collision(DinosaurMove dm) {
		if (getRec().intersects(dm.getRec())) {
			return true;
		}
		return false;
	}
	
}
