package dinosaur;


import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class DinosaurMove extends Dinosaur {
	static int count1 = 1;
	static int count2;
	int upSpeed = 40;

	private boolean jumpState = false;// 跳跃的状态
	private int jumpHeight = 130; // 跳跃的高度

	private int jumpValue = 0;// 跳跃的增变量

	Controller controller = new Controller();

	public DinosaurMove(int local_x, int local_y, int weight, int height) {
		super(local_x, local_y, weight, height);
	}

	// 设置了小恐龙图片交换（跑步）的速度
	public void drawDinosaur() {
		if (count1 <= 3) {
			setImage(Toolkit.getDefaultToolkit().getImage("image/long1.png"));
			count1++; // 1 2 3 4 5
			if (count1 == 3) {
				count2 = 3;
			}
		} else if (count2 >= 1) {
			setImage(Toolkit.getDefaultToolkit().getImage("image/long2.png"));
			count2--; // 5 4
			if (count2 == 1) {
				count1 = 1;
			}
		}
	}

	// 添加小恐龙的事件监听 按下空格的时候 小恐龙会跳起
	public class Controller extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {
			// 按下空格时小恐龙会跳跃 小恐龙初始为460的高度
			int keyCode = e.getKeyCode();
			if (keyCode == KeyEvent.VK_SPACE) {
				jumpState = true;
				new Thread(new Music("music/jump.wav")).start();
			}
		}
	}

	// 移动
	public void move() {
		if (jumpState) {
			if (local_y >= 470) { 	// 470是你的地板高度，如果最开始站在地上 增变量设为负数 开始减 往上跳
				jumpValue = -upSpeed;
			}
			if (local_y <= 470 - jumpHeight) { // 跳起来jumpHeight的高度之后 增变量设为正数 开始减 往下跳
				jumpValue = upSpeed;
			}
			local_y += jumpValue;

			if (local_y >= 470) { // 再次落灰地面时 跳跃结束
				jumpState = false;
			}
		}
	}

	public Rectangle getRec() {
		return new Rectangle(local_x, local_y, getWeight(), getHeight());

	}
}
