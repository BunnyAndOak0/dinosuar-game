package dinosaur;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class GamePanel extends JPanel{
	static int speed = 30;
	int x1 = 0;
	int x2 = 1050;
	int yun1_x = 200;
	int yun2_x = 700;
	int count = 30;
	static boolean isFinish = false;
	static int score = 0;
	
	DinosaurMove dm = new DinosaurMove(100, 470, 50, 30);
	ArrayList<Obstacle> obstacles = new ArrayList<>();
//	Obstacle obs = new Obstacle(1050, dm.getLocal_y());
	
	//获取和设置分数
	public static int getScore() {
		return score;
	}

	public static void setScore(int score) {
		GamePanel.score = score;
	}


	//判断游戏是否结束
	public static boolean isFinish() {
		return isFinish;
	}

	public static void setFinish(boolean isFinish) {
		GamePanel.isFinish = isFinish;
	}
	
	public static BufferedImage readImage(String filename) {
		try {
			BufferedImage bi = ImageIO.read(new File(filename));
			return bi;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
	
	protected void paintComponent(Graphics g) {
		//背景图片
		BufferedImage imagebackgorund1 = readImage("image/map1.png");
		BufferedImage imagebackgorund2 = readImage("image/map.png");
		BufferedImage imageyun1 = readImage("image/yun.png");
		BufferedImage imageyun2 = readImage("image/yun.png");
		
		//背景轮换
		roll(imagebackgorund1, imagebackgorund2, imageyun1, imageyun2, g);
		
		//画恐龙
		dm.drawDinosaur();
		g.drawImage(dm.getImage(), dm.getLocal_x(), dm.getLocal_y(), this);
		dm.move();
	
		count--;
		//控制障碍物生成的速度
		if (count == 0) {
			count = 30;
			obstacles.add(new Obstacle(1050, 460));
		}
		
		//一直进行重绘 使得图片动起来
		for (int i = 0; i < obstacles.size(); i++) {
			Obstacle obs = obstacles.get(i);
			
			if (obs.is_Collision(dm)) {   //碰在一起为真
//				obstacles.remove(i);      //碰在一起的话 则移除这个障碍物  暂时
				try {
					obs.draw();           //碰到之后还是要执行一次draw()  不然障碍物会消失
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				g.drawImage(obs.getImage(), obs.getO_x(), 460, 50, 53, this);
				gameOver();
				new Thread(new Music("music/hit.wav")).start();
			}else {
				try {
					obs.draw();
					obs.moveObstacles();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				g.drawImage(obs.getImage(), obs.getO_x(), 460, 50, 53, this);
			}
		}
		
		//分数显示
		g.setColor(Color.GRAY);
		g.setFont(new Font(Font.DIALOG, Font.BOLD, 15));// 字体随意找了一个 加粗"
		g.drawString("HI", 870, 35);
		g.drawString(String.format("%05d", GameFrame.topScore), 920, 35);// %05d 五位数，没有五位前面补0
		g.drawString(String.format("%05d", score), 980, 35);
		
		score += 50;     //按照时间计算分数
		
	}

	public void roll(BufferedImage image1, BufferedImage image2, BufferedImage imageyun1, 
			BufferedImage imageyun2, Graphics g) {
		x1 -= speed;       //x1=0   x2=1050
		x2 -= speed;
		yun1_x -= speed;
		yun2_x -= speed;
		
		if (x1 <= -1050) {
			x1 = 0;
		}
		
		if (x2 <= 0) {
			x2 = 1050;
		}
		
		if (yun1_x <= -81) {
			yun1_x = 1050;
		}
		
		if (yun2_x <= -81) {
			yun2_x = 1050;
		}
		
		g.drawImage(image1, x1, 0, GameFrame.Frame_wight, GameFrame.Frame_height, null);
		g.drawImage(image2, x2, 0, GameFrame.Frame_wight, GameFrame.Frame_height, null);
		g.drawImage(imageyun1, yun1_x, 100, 81, 22, null);
		g.drawImage(imageyun2, yun2_x, 175, 81, 22, null);
	}
	
	public void gameOver() {
		GamePanel.setFinish(true);
		
		if (score > GameFrame.topScore) {
			GameFrame.topScore = score;
		}
	}
}
