package dinosaur;

import java.awt.Image;

public class Dinosaur {
	int local_x;
	int local_y;
	int weight;
	int height;
	
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}

	Image image;

	public int getLocal_x() {
		return local_x;
	}
	public void setLocal_x(int local_x) {
		this.local_x = local_x;
	}
	public int getLocal_y() {
		return local_y;
	}
	public void setLocal_y(int local_y) {
		this.local_y = local_y;
	}
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
	
	public Dinosaur(int local_x, int local_y, int weight, int height) {
		this.local_x = local_x;
		this.local_y = local_y;
		this.weight = weight;
		this.height = height;
	}
	
}
