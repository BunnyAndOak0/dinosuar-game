package dinosaur;

import java.awt.Container;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

public class GameFrame extends JFrame{
	static final int Frame_wight = 1050;
	static final int Frame_height = 600;
	
	GamePanel GP = new GamePanel();
	static int topScore = 0;
	
	public void setFrame() {
		JFrame jf = new JFrame();
		jf.setSize(Frame_wight, Frame_height);
		jf.setLocation(500, 200);
		jf.add(GP);
		jf.addKeyListener(GP.dm.controller);
		jf.setResizable(false);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setVisible(true);
		FreshThread thread = new FreshThread(GP);
		thread.start();
		
		new Thread(new Music("music/background.wav")).start();    //new一个线程播放背景音乐
	}
	
	public static void main(String[] args) {
		new GameFrame().setFrame();
	}
	
	public void restart() {
		Container container = getContentPane();
		container.removeAll();
		
		GamePanel gp = new GamePanel();
		container.add(gp);
		
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent event) {
				if (event.getKeyCode() == KeyEvent.VK_SPACE) {
					gp.dm.move();
				}
				
			}
		});
		
		container.validate();
		
	}
	
}
